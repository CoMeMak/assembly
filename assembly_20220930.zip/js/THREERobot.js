var intersection = null;
var intersection2 = null;


function placeCubeAt(x,y,z,approx = false)
{
	if(approx)
	{
		if((new Date().getTime()) % 2 == 0)
		{
			x += Math.random();
			y += Math.random();
		}
		else
		{
			x -= Math.random();
			y -= Math.random();			
		}
	}
	window.cube.position.set(x,y,z);
}

var human_arms = [
		[[8,0,-3],[4,-1,-3],[0,1,0],[0,5,0],[4,7,-3],[8,6,-3]],
		[[8,1,-3],[4,-1,-3],[0,1,0],[0,5,0],[4,7,-3],[8,5,-3]],
		[[8,1,-4],[4,-1,-3],[0,1,0],[0,5,0],[4,7,-3],[8,5,-4]],
		[[8,1,-4],[4,-2,-3],[0,1,0],[0,5,0],[4,8,-3],[8,5,-4]],
		[[8,1,-4],[4,-2,-3],[0,1,0],[0,5,0],[4,7,-3],[8,6,-3]],
		[[10,1,-4],[4,-2,-3],[0,1,0],[0,5,0],[4,7,-3],[8,6,-3]],
		[[10,3,-4],[4,-1,-3],[0,1,0],[0,5,0],[4,7,-3],[8,6,-3]],
		[[10,3,-2],[4,-1,-2],[0,1,0],[0,5,0],[4,7,-1],[8,6,1]],
		[[10,3,-2],[4,-1,-2],[0,1,0],[0,5,0],[4,7,-1],[8,6,1]],
		[[10,3,-2],[4,-1,-2],[0,1,0],[0,5,0],[4,7,-1],[8,6,1]],

	];
	var interpolated_arms = [];
	function getRndInt(min, max) {
	  return Math.floor(Math.random() * (max - min) ) + min;
	}
	
	function interpolateArms()
	{
		for(var i=0;i<human_arms[0].length;i++)
		{
			var points = [];
			for(var j=0;j<human_arms.length;j++)
			{
				f = 0.03;
				points.push(new THREE.Vector3(human_arms[j][i][0]+getRndInt(1,10)*f,human_arms[j][i][1]+getRndInt(1,10)*f,human_arms[j][i][2]+getRndInt(1,10)*f));
			}
			arms_curve = new THREE.CatmullRomCurve3(points);
			points = arms_curve.getPoints(100);
			interpolated_arms.push(points);
		}
		
	}
	
const THREERobot = function (V_initial, limits, scene) {
  this.THREE = new THREE.Group()

  this.robotBones = []
  this.joints = []

  const scope = this

  let parentObject = this.THREE
  // parentObject.rotation.x = Math.PI / 2

  // let colors = [
  //     0x05668D,
  //     0x028090,
  //     0x00A896,
  //     0x02C39A,
  //     0xF0F3BD,
  //     0x0
  // ]
  const colors = [
    
	0xaaaaaa,
	0xbbbbbb,
    0xbcbcbc,
    0xcbcbcb,
    0xc0c0c0,
    0x0,
	
  ]
  
  
  /*
  const colors = [
    0x73B0F5,
    0x5C8DC5,
    0x48709D,
    0x3C5E83,
    0x304B69,
    0x0,
  ]
  */
	
	
	var handbox = [1,1,1,1];
	const channel = new BroadcastChannel('hands');
	channel.addEventListener ('message', (event) => {
		console.log(event.data);
		if(event.data.length > 0)
		{
			handbox = event.data[0].bbox;				
		}
	});
	
	window.sceneObjects = [];
	
	var arrowHelper = null;
	var box = null;
	
	var xing1 = null;
	var xing2 = null;
	window.rotateObstacle = true;
	window.scene = scene;
	
	function lerp(a, b, t) {return a + (b - a) * t}
	function ease(t) { return t<0.5 ? 2*t*t : -1+(4-2*t)*t}
	
	var t = 0, dt = 0.0007;
	// curl -d "<?xml version='1.0'?><methodCall><methodName>getBN</methodName></methodCall>" http://localhost:1337/
	
	var HANDS = false;
	var cycle = 0;
	
	$(document).ready(function() {
		// code here
		setInterval(projectObstacle,100);
	});
	
	function createRobotGroup()
		{
			
			var group = new THREE.Group();
			
			for(var i=0;i<jpos.length;i++)
			{
				var w = 0.8;
				var sphere = new THREE.Mesh( new THREE.SphereGeometry( w,w,w ), new THREE.MeshBasicMaterial( {color: 0xc0c0c0, wireframe: true} ) );
				sphere.position.set(jpos[i][0],jpos[i][1],jpos[i][2]);
				group.add(sphere);				
			}
			
			//const cylinder = new THREE.Mesh( new THREE.CylinderGeometry( 0.2, 0.2, 3, 32 ), new THREE.MeshBasicMaterial( {color: 0x000000} ) );
			//group.add( cylinder );
			for(var i=0;i<jpos.length-1;i++)
			{
				var p1 = new THREE.Vector3(jpos[i][0],jpos[i][1],jpos[i][2]);
				var p2 = new THREE.Vector3(jpos[i+1][0],jpos[i+1][1],jpos[i+1][2]);
				var dir = new THREE.Vector3(); // create once an reuse it
				dir = dir.subVectors( p2, p1 ).normalize();
				var arrowHelper = new THREE.ArrowHelper( dir, p1, p2.distanceTo(p1), 0xc0c0c0 );
				
				var lineMaterial = new THREE.LineBasicMaterial( { color: 0xc0c0c0, linewidth: 10 } );
				arrowHelper.line.material = lineMaterial;
				arrowHelper.setLength(p2.distanceTo(p1), 0, 0.5);
				group.add(arrowHelper);
			}
			return group;
			
			
		}
	
	//var jointGroup = createRobotGroup();
	var rbh = null;
	var rbb = null;
	var robotPoints = [];
	var wireLine = null;
	var ah = null;
	
	var tube = null;
	var vtubes = [];
	var vtube_delta = 1;
	var vtube_num = 10;
	//var tube3 = null;
	var tube_material = new THREE.MeshBasicMaterial( {color: 0x072534, wireframe: true} );
	//new THREE.MeshPhongMaterial( { color: 0x156289, emissive: 0x072534, side: THREE.DoubleSide, flatShading: true } );
	var main_tube_material = new THREE.MeshPhongMaterial( { color: 0x156289, emissive: 0x072534, side: THREE.DoubleSide, flatShading: true } );
	tube_material.transparent = true;
	tube_material.opacity = 0.5;
	var tube_material2 = new THREE.MeshPhongMaterial( { color: 0x156289, emissive: 0x072534, side: THREE.DoubleSide, flatShading: true } );//new THREE.MeshBasicMaterial( {color: 0x592f2a, wireframe: true} );	
	tube_material2.transparent = true;
	tube_material2.opacity = 0.2;
	//tube_material = new THREE.MeshPhongMaterial( { color: 0x000000, emissive: 0x2E4053, side: THREE.DoubleSide, flatShading: true } );
	
	var tube_geometry = null;
	var tube_curve = null;
	
	var x_axis = new THREE.Vector3( 1, 0, 0 );
	var y_axis = new THREE.Vector3( 0, 1, 0 );
	var z_axis = new THREE.Vector3( 0, 0, 1 );
	
	var pubsub_cnt = 0;
	var arms_cnt = 0;
	var incr = 1;
	var robotIDs = [];
	
	var jpos_guest_1 = [], jpos_guest_2 = [];
	var T1 = null,T2 = null, R1 = null, R2 = null;
	
	function convertToPoints(init_i, points,jjpos,T,R)
			{
				for(var i=init_i;i<jjpos.length;i++)
				{
					var p1;
					if(i == -1) 
					{ 
						p1 = new THREE.Vector3(0,0,-0.8); 
					}
					else if(i == -2)
					{
						p1 = new THREE.Vector3(0,0,-2);
					}
					else
					{				
						p1 = new THREE.Vector3(jjpos[i][0],jjpos[i][1],jjpos[i][2]);
					}
					
					p1.applyAxisAngle( x_axis, R.rx );
					p1.applyAxisAngle( y_axis, R.ry );
					p1.applyAxisAngle( z_axis, R.rz );
					
					p1.x += T.x;
					p1.y += T.y;
					p1.z += T.z;
					
					points.push(p1);
					
				}
			}
		
	var id1 = null, id2 = null;
	
	var points = [];
		
	var protectionWall = null;
	
	function boundRobot(jpos,T,R,S,ID)
	{
		window.S = S;
		window.R = R;
		window.T = T;
		if(id1 == null)
		{
			id1 = ID;
		}
		else if(ID != id1 && id2 == null)
		{
			id2 = ID;
		}
		
		if(id2 != null && id2 == ID)
		{
			jpos_guest_2 = jpos;
			T2 = T;
			R2 = R;			
		}
		else if(id1 != null && id1 == ID)
		{
			jpos_guest_1 = jpos;
			T1 = T;
			R1 = R;
		}
		
		pubsub_cnt += incr;
		if(pubsub_cnt == -1) incr = 1;
		
		var jjpos = [];//jpos;
		
		if(window.Params.arms)
		{
			if(protectionWall == null)
			{
				const geometry = new THREE.BoxGeometry( 8, 20, 0.1 );//new THREE.PlaneGeometry( 30, 30 );
				const material = new THREE.MeshBasicMaterial( {color: 0xE3F2FD, side: THREE.DoubleSide,  transparent: true, opacity: 0.05} );
				protectionWall = new THREE.Mesh( geometry, material );
				  //plane.rotation.x = Math.PI / 2
				  //plane.position.z -= 0.801
				protectionWall.position.z += 7;
				protectionWall.position.x += 7;
				protectionWall.rotation.y = Math.PI / 2;
				scene.add( protectionWall );		
				var geo = new THREE.EdgesGeometry( protectionWall.geometry );
				var mat = new THREE.LineBasicMaterial( { color: 0xCFD8DC, linewidth: 4 } );
				var wireframe = new THREE.LineSegments( geo, mat );
				wireframe.renderOrder = 1; // make sure wireframes are rendered 2nd
				protectionWall.add( wireframe );				
			}
			
			if(interpolated_arms.length == 0)
			{
				interpolateArms();
			}
			
			jjpos = []; //#human_arms[pubsub_cnt % 4];
			
			for(var i=0;i<interpolated_arms.length;i++)
			{
				var idx = pubsub_cnt % (interpolated_arms[i].length);
				if(idx == interpolated_arms[i].length - 1) incr = -1;
				jjpos.push((interpolated_arms[i][idx]).toArray());	
			}
			points = [];
			id1 = ID;
			id2 = null;
			convertToPoints(0,points,jjpos,T,R);
			//tube_material = new THREE.MeshPhongMaterial( { color: 0x000000, emissive: 0xc0c0c0, side: THREE.DoubleSide, flatShading: true } );
		}
		else
		{
			if(protectionWall != null) scene.remove( protectionWall );
			var points1 = [];
			convertToPoints(-2,points1,jpos_guest_1,T1,R1);
			
			if(id2 != null)
			{
				var points2 = [];
				convertToPoints(-2,points2,jpos_guest_2,T2,R2);
				points1 = points1.reverse();
				points = [...points1,...points2];
			}
			else
			{
				points = points1;
			}
		}
	}
	
	function renderGuests()
	{
		if(tube_geometry == null)
		{
			tube_curve = new THREE.CatmullRomCurve3(points);
			tube_geometry = new THREE.TubeGeometry( tube_curve, tube_curve.points.length, 1, 10, false );
			tube_geometry.dynamic = true;
			tube = new THREE.Mesh( tube_geometry, main_tube_material );
			scene.add(tube);
		
			for(var t=0;t<vtube_num;t++)
			{
				var vtube = new THREE.Mesh( tube_geometry, tube_material2 );
				
				//scene.add(vtube);
				vtubes.push(vtube);
			}
			// TUBE 2 and 3
			
			
			//tube3 = new THREE.Mesh( tube_geometry, tube_material2 );
			//scene.add(tube3);
			
		}
		else
		{
			//tube_curve.points = points;
			tube_curve = new THREE.CatmullRomCurve3(points);
			//tube.rotation.set(R.rx,R.ry,R.rz);
			//tube.position.set(T.x,T.y,T.z);
			
			tube.geometry = new THREE.TubeGeometry( tube_curve, tube_curve.points.length * 3,  1, 10, false );
			
			var sf = window.S / Params.placement.S;
			tube.scale.set(sf,sf,sf);

			
			for(var t=0;t<vtubes.length;t++)
			{
				vtubes[t].scale.set(sf,sf,sf);
				vtubes[t].geometry = new THREE.TubeGeometry( tube_curve, tube_curve.points.length * 3,  1, 10, false );
				var trans_delta = -(t+1) * vtube_delta * window.S;
				vtubes[t].geometry.translate(0,0,trans_delta);
			}
			/*
			// TUBE 2 and 3
			tube2.scale.set(sf,sf,sf);
			tube2.geometry = new THREE.TubeGeometry( tube_curve, 25,  1, 5, false );
			tube2.geometry.translate(0,0,-1.8);
			
			tube3.scale.set(sf,sf,sf);
			tube3.geometry = new THREE.TubeGeometry( tube_curve, 25,  1, 5, false );
			tube3.geometry.translate(0,0,-3.6);
			*/
			//tube_curve.needsUpdate = true;
			//tube.geometry.verticesNeedUpdate = true;
			//tube.updateMatrix();
			window.collision_points = points;
			
		}
		
		if(rbh == null)
		{
			rbb = new THREE.Box3();
			
			rbb.setFromObject( tube );
			rbh = new THREE.BoxHelper( tube, 0xffff00 );
			
			scene.add(rbh);
		}
		
		rbh.update(tube);
	}
	/*
	var urlParams = getUrlVars();
	if(urlParams["role"] != null && urlParams["role"] == "host")
	{
		g2h.addEventListener("message", e => {
			if(e.data.ID != sessionID)
			{
				boundRobot(e.data.jpos,e.data.T,e.data.R,e.data.S);			
			}
		});
	}
	*/
	var old_date = 0;
	g2h.addEventListener("message", e => {
		if(e.data.ID != sessionID)
		{
			if($("#is_host").is(":checked"))
			{
				var new_date = Date.now();
				//console.log( (new_date - old_date) );
				old_date = new_date;
				boundRobot(e.data.jpos,e.data.T,e.data.R,e.data.S,e.data.ID);	
			}
			else
			{
				scene.remove(tube);
				scene.remove(rbh);
				rbh = null;
			}
		}
	});
	
	var showObstacle = false;
	window.PO = function()
	{
		projectObstacle();
	}
	function projectObstacle()
	{
		if(id1 != null)
		{
			renderGuests();
		}
		
		cycle++;
		Vars.obstacle = null;
		
		if(rbb == null && showObstacle)
		{
			if(box == null)
			{
				var mat = new THREE.MeshLambertMaterial({
					color: 0x5D6D7E,
					emissive: 0x2a2a2a,
					emissiveIntensity: .5,
					side: THREE.DoubleSide
				});
				var geometry = new THREE.BoxGeometry(1, 1, 1);
				
				try{
					scene.remove(obstacle);
				}
				catch(e){
					console.log("obstacle not in scene");
				}
				
				obstacle = new THREE.Mesh(geometry, mat);
				scene.add(obstacle);
				
				if(plane == "horizontal")
				{
					obstacle.position.set(5,0,1);
				}
				else
				{
					obstacle.position.set(3,3,1);
				}
				
				obstacle.scale.set(1.5, 4.5, 2.5);
				scene.add(obstacle);
				box = new THREE.BoxHelper( obstacle, 0xffff00 );
				scene.add( box );									
			}		
			
			if(!HANDS)
			{
				var a = {x: 4, y: 3, z: 1}, b = {x: 5.5, y: 0.5, z: 2};
				if(plane == "horizontal")
				{
					a = {x: 5, y: -1, z: 1}; 
					b = {x: 6.5, y: 1, z: 1};			
				}
				
				var newX = lerp(a.x, b.x, ease(t));   // interpolate between a and b where
				var newY = lerp(a.y, b.y, ease(t));   // t is first passed through a easing
				var newZ = lerp(a.z, b.z, ease(t));   // function in this example.
			
				obstacle.position.set(newX, newY, newZ);  // set new position
				t += dt;
			
				if (t <= 0 || t >=1) 
				{
					dt = -dt; 
					waitThere = true;			
				}
				
				obstacle = obstacle.rotateZ(0.0008);
				obstacle = obstacle.rotateY(0.0008);
				obstacle = obstacle.rotateX(0.0008);
			}
			else if(cycle % 10 == 0)
			{
				
				var w = handbox[2] / 100;
				var h = handbox[3] / 100;
				var y = handbox[0] / 50;
				var z = handbox[1] / 100;
				
				h = 6 - z;
				console.log(handbox);
				
				var a = w * h / 5;
				obstacle.scale.set(5, w, h);			
				//obstacle.position.set(h, w, 1 + h);
				obstacle.position.set(4, y/2, h/2 - 0.8);
			}
			
			box.update(obstacle);			
		}
		else
		{
			scene.remove(obstacle);
			scene.remove( box );
		}
		
		if(Robot.origin == null) return;
		
		var bbox;
		if(rbh != null)
		{
			bbox = new THREE.Box3().setFromObject(rbh);			
		}
		else if(box != null)
		{
			
			bbox = new THREE.Box3().setFromObject(box);
		}
		else
		{
			return;
		}
		
		var sc = {"x": (bbox.max.x + bbox.min.x) / 2, "y": c_y = (bbox.max.y + bbox.min.y) / 2, "z": (bbox.max.z + bbox.min.z) / 2};
		
		window.bsphere = new THREE.Sphere(sc,5);
		
		//var origin = new THREE.Vector3(Robot.origin.x / 100, Robot.origin.y / 100, (Robot.origin.z - 80) / 100);
		var origin = new THREE.Vector3(Robot.origin.x / 100, Robot.origin.y / 100, (Robot.origin.z - 80) / 100);
		var origin_bkp = new THREE.Vector3(Robot.origin.x / 100, Robot.origin.y / 100, (Robot.origin.z - 80) / 100);
		
		var target = new THREE.Vector3(Robot.target.tcp.x / 100, Robot.target.tcp.y / 100, (Robot.target.tcp.z - 80) / 100);
		var tcp = new THREE.Vector3(Robot.tcp.x / 100, Robot.tcp.y / 100, (Robot.tcp.z - 80) / 100);
		
		var origin_rect = new THREE.Vector3(origin.x,origin.y,tcp.z);
		
		var alpha = Math.asin((tcp.z - target.z) / tcp.distanceTo(target));
		
		window.z_rect = Math.tan(alpha) * tcp.distanceTo(origin_rect);
		origin.z = tcp.z + window.z_rect;
		
		//origin = tcp;
		
		//origin.lerp(tcp,0.5);
		//console.log("ORIGIN: " + origin.x + " " + origin.y + " " + origin.z);
		
		var dir = new THREE.Vector3(); // create once an reuse it
		dir = dir.subVectors( target, origin ).normalize();
		
		var dir2 = new THREE.Vector3(); // create once an reuse it
		dir2 = dir2.subVectors( origin, target ).normalize();
		
		var ray = new THREE.Raycaster(origin,dir);
		var ray2 = new THREE.Raycaster(target,dir2);
		
		var vvtubes = [...vtubes];
		vvtubes.push(tube);
		
		intersection = ray.intersectObjects(vvtubes);
		intersection2 = ray2.intersectObjects(vvtubes);
		
		//intersection2 = intersection2.reverse();
		
		var upper_z = -1;
		
		if(intersection.length > 0)
		{
			function computeUpperZ(intersection)
			{
				var upper_z = intersection[0].point.z;
				for(var t=0;t<vvtubes.length-1;t++)
				{
					if(intersection[0].object.uuid == vvtubes[t].uuid)
					{
						upper_z += (t+1) * vtube_delta * window.S;
						break;
					}
				}
				
				//if(window.arms == true) return upper_z;

				var ip = intersection[0].point;
				ip.z = upper_z;
				var min_dist = 100000;
				var min_idx = -1;
				for(var cpp=0;cpp<tube_curve.points.length;cpp++)
				{
					var cp = tube_curve.points[cpp];
					if(cp.distanceTo(ip) < min_dist)
					{
						min_dist = cp.distanceTo(ip);
						min_idx = cpp;
					}
				}
				var min_point = tube_curve.points[min_idx];
				
				if(ip.z < min_point.z)
				{
					upper_z += min_point.z - ip.z;
				}
				else if(ip.z > min_point.z && min_idx < tube_curve.points.length - 1 && min_idx > 0)
				{
					if(tube_curve.points[min_idx + 1].z > min_point.z)
					{
						upper_z += tube_curve.points[min_idx + 1].z - ip.z;
					}
					else if(tube_curve.points[min_idx - 1].z > min_point.z)
					{
						upper_z += tube_curve.points[min_idx - 1].z - ip.z;
					}
					else
					{
						upper_z += min_point.z - ip.z;
					}
				}
				return upper_z;
			}
			
			//if(!window.Params.arms)
			//{
			upper_z = computeUpperZ(intersection);
			//}
			//upper_z2 = upper_z;
			
			
			intersection = intersection[0].point;
			
			if(intersection2.length > 0)
			{
				//upper_z2 = computeUpperZ(intersection2);
				intersection2 = intersection2[0].point;				
			}
			else
			{
				intersection2 = intersection;
				//upper_z2 = upper_z;
			}
			
			//intersection.lerp(origin,0.2);
			//intersection2.lerp(target,0.2);			
		}
		else
		{
			intersection = null;			
		}
		
		
		var bbox2;
		if(rbh != null)
		{
			bbox2 = new THREE.Box3().setFromObject(rbh);			
		}
		else
		{
			bbox2 = new THREE.Box3().setFromObject(box);
		}
		
		
		bbox2.max.x += buf; bbox2.max.y += buf; bbox2.max.z += buf;
		bbox2.min.x -= buf; bbox2.min.y -= buf; bbox2.min.z -= buf;
		window.bbox = bbox2;
		
		origin = new THREE.Vector3(Robot.origin.x / 100, Robot.origin.y / 100, (Robot.origin.z - 80) / 100);		
		//origin = origin_bkp;
		if(intersection != null)
		{
			var obst = {};
			
			if(target.z == origin.z)
			{
				origin.z += origin.z * 0.01;
			}
			
			if(plane == "vertical")
			{

				//var sin_alpha = Math.abs(target.z - origin.z) / origin.distanceTo(target);
				//var cos_alpha = Math.sqrt(Math.pow(target.x - origin.x,2) + Math.pow(target.y - origin.y,2)) / origin.distanceTo(target);
				
				//var p = {z: bbox.max.z};
				
				var p = {z: upper_z};
				if(ATTACH)
				{
					p.z += 1;
				}
				//var p_down = {z: (upper_z)};
				
				obst.x_up = origin.distanceTo(intersection) * 100;
				//if(origin.z > target.z) obst.x_up -= 100 * Math.abs(p.z - intersection.z) * sin_alpha;
				
				obst.x_down = origin.distanceTo(intersection2)  * 100;
				//if(origin.z < target.z) obst.x_down += 100 * Math.abs(p.z - intersection2.z) * sin_alpha;

				//obst.y_up = cos_alpha * (p.z - intersection.z)  * 100;
				//obst.y_down = cos_alpha * (p.z - intersection2.z)  * 100;
				
				// new calculation
				obst.y_up = p.z * 100;
				obst.y_down = p.z * 100;
				
				obst.dist = origin.distanceTo(target) * 100;
				
				//obst.perimeter = intersection.distanceTo(intersection2) * 100 + obst.y_up + obst.y_down + cos_alpha * intersection.distanceTo(intersection2) * 100;
				//var i1 = intersection; i1.z = cos_alpha * (p.z - intersection.z);
				//var i2 = intersection2; i2.z = cos_alpha * (p.z - intersection2.z);
				
				//obst.perimeter = (origin.distanceTo(i1) + i1.distanceTo(i2) + i2.distanceTo(target)) * 100;				
				obst.perimeter = 100;
				obst.perimeter = (origin.distanceTo(intersection) + intersection.distanceTo(intersection2) + intersection2.distanceTo(target)) * 100;
				
				window.Vars.obstacle = obst;
				//console.log("INTERSECTIONS: " + intersection.z + " - " + window.Vars.obstacle.y_up + " - " + window.Vars.obstacle.y_down);				
			}
			
			else // horizontal
			{

				bbox.min.z = 0;
				var sin_alpha = Math.abs(target.x - origin.x) / origin.distanceTo(target);
				var cos_alpha = Math.sqrt(Math.pow(origin.distanceTo(target),2) - Math.pow(target.x - origin.x,2)) / origin.distanceTo(target);
				
				obst.x_up = origin.distanceTo(intersection) * 100;
				
				var p = {x: bbox.min.x};
				//var p = {x: upper_x};
				if(origin.x > target.x) obst.x_up -= 100 * Math.abs(p.x - intersection.x) * sin_alpha;
				
				//obst.y_up = -cos_alpha * (p.x - intersection.x)  * 100;
				obst.y_up = cos_alpha * (intersection.x - p.x) * 100;
				

				obst.x_down = origin.distanceTo(intersection2)  * 100;
				
				if(origin.x < target.x) obst.x_down += 100 * Math.abs(p.x - intersection2.x) * sin_alpha;

				//obst.y_down = -cos_alpha * (p.x - intersection2.x)  * 100;
				
				obst.y_down = cos_alpha * (intersection2.x - p.x) * 100;
				
				obst.dist = origin.distanceTo(target) * 100;
				
				//obst.perimeter = intersection.distanceTo(intersection2) * 100 + obst.y_up + obst.y_down + cos_alpha * intersection.distanceTo(intersection2) * 100;
				var i1 = intersection; i1.x = cos_alpha * (p.x - intersection.x);
				var i2 = intersection2; i2.x = cos_alpha * (p.x - intersection2.x);
							
				
				obst.perimeter = (origin.distanceTo(i1) + i1.distanceTo(i2) + i2.distanceTo(target)) * 100;
				
				//console.log("x_up = " + obst.x_up + " x_down = " + obst.x_down);
				Vars.obstacle = obst;				

			}
			
			
			const material = new THREE.MeshBasicMaterial( {color: 0xFF0000} );
			var geometry = new THREE.SphereGeometry( 0.05, 0.05, 0.05 );
			
			if(xing1 == null && xing2 == null)
			{
				xing1 = new THREE.Mesh( geometry, material );
				xing2 = new THREE.Mesh( geometry, material );
				
				scene.add( xing1 );
				scene.add( xing2 );

			}

			
			xing1.position.set(intersection.x,intersection.y,p.z+1);
			xing2.position.set(intersection2.x,intersection2.y,p.z+1);
			
			
			//if(arrowHelper != null)
			//{
			//	scene.remove(arrowHelper);
			//}
				
			//arrowHelper = new THREE.ArrowHelper( dir, tcp, obst.dist / 100, 0xc0c0c0 );
			//arrowHelper.setLength(tcp.distanceTo(target), 0.4, 0.2);
			
			//arrowHelper = new THREE.ArrowHelper( dir, origin, obst.dist / 100, 0xc0c0c0 );
			//arrowHelper.setLength(origin.distanceTo(target), 0.4, 0.2);
			
			//scene.add( arrowHelper );
			
			
		}
		else
		{
			window.Vars.obstacle = null;
			scene.remove( xing1 );
			scene.remove( xing2 );
			xing1 = null;
			xing2 = null;
		}	
		
			
	}
	
	var updateMarkersInt = -1;
	
	
	
	var obstacle = null;
	createObjects();
	function createObjects()
	{
		
		var mat = new THREE.MeshLambertMaterial({
				color: 0x73B0F5,
				emissive: 0x2a2a2a,
				emissiveIntensity: .5,
				side: THREE.DoubleSide
		});
		
		
		var geometry = new THREE.BoxGeometry(0.01, 0.01, 0.01);
		window.cube = new THREE.Mesh(geometry, mat);

		
		window.cube.position.set(3,3,-1.6);
		
		geometry = new THREE.BoxGeometry(1, 1, 1);
		var cube2 = new THREE.Mesh(geometry, mat);
		
		cube2.position.set(0,0,1.3);
		cube.add( cube2 );	
		
		scene.add(cube);
		sceneObjects.push({o:cube,d:2.7});
		
		moveObjects();
	}
	
	var odd = true;
	function moveObjects()
	{
		for(var i=0;i<sceneObjects.length;i++)
		{
			var obj = sceneObjects[i];
			var attraction = 1;
			var cond = (Math.abs(obj.o.position.x - Robot.tcp.x / 100) < attraction && Math.abs(obj.o.position.y - Robot.tcp.y / 100) < attraction && (Robot.tcp.z / 100) - obj.o.position.z < obj.d);
			
			if(ATTACH && cond)
			{
				var dtr = 0.0174533;
				obj.o.position.set(Robot.tcp.x / 100,Robot.tcp.y / 100,Robot.tcp.z / 100);
				obj.o.rotation.set(Robot.tcp.rx * dtr,Robot.tcp.ry * dtr,Robot.tcp.rz * dtr);
			}
			else
			{
				obj.o.rotation.set(0,0,0);
				obj.o.position.setZ(-1.6);	
			}
			window.Robot.cubelet = {x: obj.o.position.x * 100, y: obj.o.position.y * 100, z: obj.o.position.z * 100};
		}			
		
		if(odd)
		{	
			projectObstacle();
			odd = false;
		}
		else
		{
			odd = true;
		}
		
		setTimeout(moveObjects,50);
	}

  function createBoxWithRoundedEdges( width, height, depth, radius0 = 0.5, smoothness = 15 ) {
	  
	  let shape = new THREE.Shape();
	  let eps = 0.00001;
	  let radius = radius0 - eps;
	  shape.absarc( eps, eps, eps, -Math.PI / 2, -Math.PI, true );
	  shape.absarc( eps, height -  radius * 2, eps, Math.PI, Math.PI / 2, true );
	  shape.absarc( width - radius * 2, height -  radius * 2, eps, Math.PI / 2, 0, true );
	  shape.absarc( width - radius * 2, eps, eps, 0, -Math.PI / 2, true );
	  let geometry = new THREE.ExtrudeGeometry( shape, {
		amount: depth - radius0 * 2,
		bevelEnabled: true,
		bevelSegments: 20,
		steps: 5,
		bevelSize: radius,
		bevelThickness: radius0,
		bevelOffset: 0,
		curveSegments: smoothness
	  });
	  
	  geometry.center();
	  
	  return geometry;
}

  function createCube(x, y, z, w, h, d, min, max, jointNumber) {
    
	const thicken = 1.4
    const w_thickened = Math.abs(w) + thicken
    const h_thickened = Math.abs(h) + thicken
    const d_thickened = Math.abs(d) + thicken


    const material = new THREE.MeshLambertMaterial({
      color: colors[jointNumber],
    });
	// BoxGeometry(width : Float, height : Float, depth : Float, widthSegments : Integer, heightSegments : Integer, depthSegments : Integer)
	//CylinderGeometry(radiusTop : Float, radiusBottom : Float, height : Float, radialSegments : Integer, heightSegments : Integer, openEnded : Boolean, thetaStart : Float, thetaLength : Float)
	
	//var texture = new THREE.TextureLoader().load( 'img/task.png' );
	//const material = new THREE.MeshBasicMaterial( { map: texture } );
	
    //const geometry = new THREE.BoxGeometry(w_thickened, h_thickened, d_thickened)
	const geometry = createBoxWithRoundedEdges(w_thickened, h_thickened, d_thickened);
	const mesh = new THREE.Mesh(geometry, material)

    mesh.position.set(w / 2, h / 2, d / 2)
    const group = new THREE.Object3D()
    group.position.set(x, y, z)
    group.add(mesh)
	
	
	  const geometr = new THREE.BoxGeometry(3, 3, 3);
	  const loader = new THREE.TextureLoader();
	  texture = loader.load('img/logo.png');
	  texture.anisotropy = 5000;
	  const mater = new THREE.MeshBasicMaterial({
		map: texture,
	  });
	  
	  const cube = new THREE.Mesh(geometr, mater);
	  cube.rotation.x += Math.PI / 2;
	  
	  cube.position.set(-7,5,7)
	  //scene.add(cube);
	  
	  
	  
	  

	
	

    console.log(min, max)
    // min = min / 180 * Math.PI
    // max = max / 180 * Math.PI

	var cw = 0.82;
    
	const jointGeo1 = new THREE.CylinderGeometry(cw, cw, cw * 2, 32, 32, false, -min, 2 * Math.PI - max + min)
	//const jointGeo1 = createBoxWithRoundedEdges(cw*2, cw*2.2, cw * 2, radius0 = 0.6, smoothness = 5)
    
	const jointGeoMax = new THREE.CylinderGeometry(cw, cw, cw * 2, 32, 32, false, -max, max)
	//const jointGeoMax = createBoxWithRoundedEdges(cw*2, cw*2.2, cw * 2, radius0 = 0.6, smoothness = 5)
    
	const jointGeoMin = new THREE.CylinderGeometry(cw, cw, cw * 2, 32, 32, false, 0, -min)
    //const jointGeoMin = createBoxWithRoundedEdges(cw*2, cw*2.2, cw * 2, radius0 = 0.6, smoothness = 5)
	
	const jointMesh1 = new THREE.Mesh(jointGeo1, new THREE.MeshLambertMaterial({
      color: 0x4E92B1,
    }))
    const jointMeshMax = new THREE.Mesh(jointGeoMax, new THREE.MeshLambertMaterial({
      color: 0x4E92B1,
    }))
    const jointMeshMin = new THREE.Mesh(jointGeoMin, new THREE.MeshLambertMaterial({
      color: 0x4E92B1,
    }))

    const joint = new THREE.Group()
    // joint.add(jointMesh1, jointMesh2)
    joint.add(jointMeshMax, jointMeshMin, jointMesh1)

    scope.joints.push(joint)

    switch (jointNumber) {
      case 0:
        joint.rotation.x = Math.PI / 2
        break
      case 1:
        // joint.rotation.x = Math.PI / 2
        break
      case 2:
        // joint.rotation.x = Math.PI / 2
        break
      case 3:
        joint.rotation.z = Math.PI / 2
        // joint.rotation.y = Math.PI
        break
      case 4:
        // joint.rotation.x = Math.PI / 2
        joint.rotation.y = Math.PI / 2
        break
      case 5:
        joint.rotation.x = Math.PI / 2
        group.rotation.y = Math.PI / 2
        // group.rotation.z = Math.PI
        // group.rotation.z = -Math.PI / 2
        // group.rotation.y += Math.PI
        // joint.rotation.z = +Math.PI / 2
        // const axisHelper = new THREE.AxisHelper(3)
        // axisHelper.rotation.x = Math.PI
        // group.add(axisHelper)
        const arrowZ = new THREE.ArrowHelper(new THREE.Vector3(0, 0, 1), new THREE.Vector3(0, 0, 0), 3, 0x0000ff)
        arrowZ.line.material.linewidth = 4
        group.add(arrowZ)
        const arrowY = new THREE.ArrowHelper(new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, 0, 0), 3, 0x00ff00)
        arrowY.line.material.linewidth = 4
        group.add(arrowY)
        const arrowX = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), new THREE.Vector3(0, 0, 0), 3, 0xff0000)
        arrowX.line.material.linewidth = 4
        group.add(arrowX)
        // joint.add(getVectorArrow([0,0,0],[0,0,5]))
        break
    }

    group.add(joint)
    return group
  }

  let x = 0,
    y = 0,
    z = 0
  V_initial.push([0, 0, 0]) // add a 6th pseudo link for 6 axis
  for (let i = 0; i < V_initial.length; i++) {
    const link = V_initial[i]
    const linkGeo = createCube(x, y, z, link[0], link[1], link[2], limits[i][0], limits[i][1], i)
    x = link[0]
    y = link[1]
    z = link[2]
    //console.log(link[0], link[1], link[2])
    parentObject.add(linkGeo)
    parentObject = linkGeo
    this.robotBones.push(linkGeo)
  }

  scene.add(this.THREE)
  

  this.angles = [0, 0, 0, 0, 0, 0]
}

THREERobot.prototype = {
  setAngles(angles) {
    this.angles = angles
    this.robotBones[0].rotation.z = angles[0]
    this.robotBones[1].rotation.y = angles[1]
    this.robotBones[2].rotation.y = angles[2]
    this.robotBones[3].rotation.x = angles[3]
    this.robotBones[4].rotation.y = angles[4]
    this.robotBones[5].rotation.z = angles[5]
  },
  

  setAngle(index, angle) {
    this.angles[index] = angle
    this.setAngles(this.angles)
  },

  highlightJoint(jointIndex, hexColor) {
    if (jointIndex >= this.joints.length) {
      console.warn(`cannot highlight joint: ${jointIndex} (out of index: ${this.joints.length})`)
    }
    if (hexColor) {
      this._colorObjectAndChildren(this.joints[jointIndex], hexColor)
    } else {
      this._resetObjectAndChildrenColor(this.joints[jointIndex])
    }
  },

  _colorObjectAndChildren(object, hexColor) {
    const scope = this
    object.traverse((node) => {
      scope._colorObject(node, hexColor)
    })
  },

  _colorObject(object, hexColor) {
    if (object.material) {
      if (!object.initalMaterial) {
        object.initalMaterial = object.material
      }
      object.material = object.material.clone()
      object.material.color.setHex(hexColor)
    }
  },

  _resetObjectAndChildrenColor(object, hexColor) {
    const scope = this
    object.traverse((node) => {
      scope._resetObjectColor(node)
    })
  },

  _resetObjectColor(object) {
    if (object.initalMaterial) {
      object.material = object.initalMaterial
    }
  },

}
