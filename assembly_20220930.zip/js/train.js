function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}

var th_x_up = 0; //0.25;
var th_x_down = 1; //0.65;
var th_y = 1; //0.4;
var tol = 0.05;

function filter(tdata)
{
	var result = [];
	$.each(tdata, function (i, e) {
		var matchingItems = $.grep(result, function (item) {
		   
		   return (e.input[0] < th_x_up - tol) || (e.input[2] > th_x_down + tol) || (e.input[1] > th_y + 2*tol) || (e.input[3] > th_y + 2*tol);
		});
		if (matchingItems.length === 0){
			result.push(e);
		}
	});
	return result;
}

function removeDuplicates(tdata)
{
	var result = [];
	$.each(tdata, function (i, e) {
		var matchingItems = $.grep(result, function (item) {
		   var th = 0.003;
		   return Math.abs(item.input[0] - e.input[0]) < th && Math.abs(item.input[1] - e.input[1]) < th && Math.abs(item.input[2] - e.input[2]) < th && Math.abs(item.input[3] - e.input[3]) < th;
		});
		if (matchingItems.length === 0){
			result.push(e);
		}
	});
	return result;
}

function removeCDuplicates(tdata)
{
	var result = [];
	$.each(tdata, function (i, e) {
		var matchingItems = $.grep(result, function (item) {
		   var th = 0.001;
		   return Math.abs(item.input[0] - e.input[0]) < th && Math.abs(item.input[1] - e.input[1]) < th && Math.abs(item.input[2] - e.input[2]) < th;
		});
		if (matchingItems.length === 0){
			result.push(e);
		}
	});
	return result;
}


function sample(arr, size) {
    var shuffled = arr.slice(0), i = arr.length, temp, index;
    while (i--) {
        index = Math.floor((i + 1) * Math.random());
        temp = shuffled[index];
        shuffled[index] = shuffled[i];
        shuffled[i] = temp;
    }
    return shuffled.slice(0, size);
}

var eval_results = [];

function storeResults()
{
	var r = {	"failure": (100 * bad_cnt / (good_cnt+bad_cnt)),
				"good":good_cnt, 
				"bad": bad_cnt, 
				"rmse_b": Math.sqrt(rmse_b / bad_cnt), 
				"rmse_n": Math.sqrt(rmse_n / bad_cnt), 
				"path": (total_path / (good_cnt + bad_cnt)), 
				"smooth": (smoothness / (good_cnt + bad_cnt)),
				"time": (total_time / (good_cnt + bad_cnt))
				};
	r["th_x_up"] = th_x_up;
	r["th_x_down"] = th_x_down;
	r["th_y"] = th_y;
	r["udata"] = udata.length;
	r["ndata"] = ndata.length;
	eval_results.push(r);
}

var udata = [];
var old_ndata_length = -1;

function denormalize(arr)
{
	var a = [];
	for(var i=0;i<arr.length;i++)
	{
		a.push(dn(arr[i]));
	}
	return a;
}

//function evaluateArc(x_tgt,b,n)

function trainEvaluateArc()
{
	const config = {
	  learningRate: 0.1,
	  hiddenLayers: [16],
	  activation: 'sigmoid' // supported activation types: ['sigmoid', 'relu', 'leaky-relu', 'tanh']
	};

	const crossValidate = new brain.CrossValidate(brain.NeuralNetwork, config, k=3);
	var td = evaluateArcData;
	const stats = crossValidate.train(evaluateArcData, { log: true, iterations:4000, errorThresh: 0.00005, logPeriod: 100 }, k=3);
	console.log(stats);
	const net = crossValidate.toNeuralNetwork();
	var json = net.toJSON();
	var jnn = JSON.stringify(json);
	console.log(jnn);		
	
	var mape = 0;
	var _T = 0;
	for(var i=0; i< evaluateArcData.length; i++)
	{
		_T += evaluateArcData[i].output[0];
	}
	
	_T = _T / evaluateArcData.length;
	var T = 0;
	
	var tests = 0;
	for(var i=0; i< evaluateArcData.length; i++)
	{

		o = net.run(evaluateArcData[i].input);
		mape += Math.pow(o[0] - evaluateArcData[i].output[0], 2);
		T += Math.pow(evaluateArcData[i].output[0] - _T, 2);
	}
	console.log((Math.sqrt(mape / T)).toFixed(3));	
}

function trainTestEllipse()
{
	const config = {
	  learningRate: 0.1,
	  binaryThresh: 0.5,
	  hiddenLayers: [4],
	  activation: 'sigmoid' // supported activation types: ['sigmoid', 'relu', 'leaky-relu', 'tanh']
	};

	const crossValidate = new brain.CrossValidate(brain.NeuralNetwork, config, k=3);
	const stats = crossValidate.train(testEllipseData, { log: true, iterations:2000, errorThresh: 0.0006, logPeriod: 100 }, k=3);
	console.log(stats);
	const net = crossValidate.toNeuralNetwork();
	var json = net.toJSON();
	var jnn = JSON.stringify(json);
	console.log(jnn);	
	
	var tests = 0;
	for(var i=0; i< testEllipseData.length; i++)
	{
		var o = net.run(testEllipseData[i].input);
		var denormalized = denormalize(testEllipseData[i].input);
		var test = testEllipse(100,...denormalized);
		
		if((test >= 1 && Math.round(o[0]) == 0) || (test < 1 && Math.round(o[0]) == 1))
		{			
			tests++;			
		}
	}	
	console.log(tests);
}

var testEllipseData = [];
var evaluateArcData = [];
var trainingdata = [];

function mmtd()
{
	var td = trainingdata;
	var zc = 0;
	var min = 100000;
	var max = -100000;
	for(var i=0;i<td.length;i++)
	{
		if(td[i].input[0] < min) min = td[i].input[0];
		if(td[i].input[0] > max) max = td[i].input[0];
		if(td[i].input[0] == 0)zc++;
	}
		
	console.log(min);
	console.log(max);
	console.log(zc);
}

function remDup(td)
{
	var hash = {};
	var new_td = [];
	for(var i=0;i<td.length;i++)
	{
		var key = td[i].input[0].toString();
		if(!hash.hasOwnProperty(key))
		{
			hash[key] = 1;
			new_td.push(td[i]);
		}		
	}
	return new_td;
}


function testTrain()
{
	trainingdata = tdata.slice(0,1000);	
	var bn;
	window.recompute = false;
	for(var i=0; i<trainingdata.length; i++)
	{
		//bn = ellipseParams(100,dn(trainingdata[i].input[0]),dn(trainingdata[i].input[1]),dn(trainingdata[i].input[2]),dn(trainingdata[i].input[3]));
		//bn[0] = norm(bn[0]);
		//bn[1] = norm(bn[1]);
		//trainingdata[i].output = [trainingdata[i].output[0]];
		var bn = trainingdata[i].output;
		if(window.recompute || (bn[0] == null || bn[1] == null || bn[0] == 0 || bn[1] == 0)) 
		{
			bn = ellipseParams(100,dn(trainingdata[i].input[0]),dn(trainingdata[i].input[1]),dn(trainingdata[i].input[2]),dn(trainingdata[i].input[3]));
			bn[0] = norm(bn[0]);
			bn[1] = norm(bn[1]);
		}
		trainingdata[i].output = [parseFloat(bn[0]),parseFloat(bn[1])];
	}
	const config = {
	  learningRate: 0.1,
	  hiddenLayers: [8],
	  activation: 'sigmoid' // supported activation types: ['sigmoid', 'relu', 'leaky-relu', 'tanh']
	};
	
	trainBN(config,trainingdata,0.0001);
}

function generateData(size)
{
	var arr1 = [];
	while(arr1.length < size){
		var r = Math.random();
		if(arr1.indexOf(r) === -1 && r > 0.01 && r < 0.99)
		{			
			arr1.push(r);
		}
	}
	
	var arr2 = [];
	while(arr2.length < size){
		var r = Math.random();
		if(arr2.indexOf(r) === -1 && r > 0.1 && r < 0.99)
		{			
			arr2.push(r);
		}
	}
	
	var td = [];
	for(var i=0;i<size;i++)
	{
		td.push({input: [parseFloat(arr1[i]),parseFloat(arr2[i])],output: [0]});
	}
	return td;
}

function trainBN(config,td,eth,norm_td = true,recurrent=false)
{
	window.manipulate = false;
	function normalize(td)
	{
		//function minmax(val, max, min) { return (val - min) / (max - min); }
		function minmax(val, min, max, a, b) { 
			var x = ((b - a)*((val - min) / (max - min)) + a);
			return x;
		}
		
		var min = 1000;
		var max = -1000;
		
		for(var i=0;i<td.length;i++)
		{
			if(min > td[i].output[0]) min = td[i].output[0];
			if(max < td[i].output[0]) max = td[i].output[0];
		}
			
		for(var i=0;i<td.length;i++)
		{
			td[i].output[0] = minmax(td[i].output[0],min,max,0.3,0.7);
			//td[i].input[0] = minmax(td[i].input[0],-0.5,0.5);
			//td[i].input[1] = minmax(td[i].input[1],-0.5,0.5);
		}
		return td;
	}
	
	if(norm_td) td = normalize(td);
	
	var net = null;
	if(recurrent) 
	{
		td.sort(function (a, b) {
			return a.input[0] - b.input[0];
		});		
		
		net = new brain.recurrent.LSTM(config);
		const result = net.train(td, { log: true, iterations:100, errorThresh: eth, logPeriod: 10 });
		console.log(result);
	}
	else
	{
		const crossValidate = new brain.CrossValidate(brain.NeuralNetwork, config, k=3);
		const stats = crossValidate.train(td, { log: true, iterations:500, errorThresh: eth, logPeriod: 200 }, k=3);
		console.log(stats);
		net = crossValidate.toNeuralNetwork();
	}
	
	
	
	
	//const net = new brain.NeuralNetwork(config);
	//net.train(td, { log: true, iterations:5000, errorThresh: eth, logPeriod: 200 }, k=3);
	
	//var json = net.toJSON();
	//var jnn = JSON.stringify(net.toJSON());
	//console.log(jnn);
	
	function computeError(out)
	{
		var diff = 0;
		var mape = 0;
		var _T = 0;
		for(var i=0; i< td.length; i++)
		{
			_T += td[i].output[0];
		}
		
		_T = _T / td.length;
		var T = 0;
		
		for(var i=0; i< td.length; i++)
		{
			o = net.run(td[i].input);
			//var test = testEllipse(100,dn(trainingdata[i].input[0]),dn(trainingdata[i].input[1]),dn(trainingdata[i].input[2]),dn(trainingdata[i].input[3]),dn(o[0]),dn(o[1]));
			//var arc = evaluateArc(100,dn(td[i].output[0]),dn(td[i].output[1]));
			//evaluateArcData.push({input: [td[i].output[0],td[i].output[1]], output: [arc/1000]});
			//if(test >= 1)
			diff += Math.pow(o[out] - td[i].output[out], 2);
			T += Math.pow(td[i].output[out] - _T, 2);		
			if(td[i].output[out] > 0) 
				mape += Math.abs((o[out] - td[i].output[out])) / (Math.abs(td[i].output[out]) + Math.abs(o[out]));
		}
		console.log((Math.sqrt(diff / T)).toFixed(6));	
		console.log((100/td.length) * mape);	
		
		return [((Math.sqrt(diff / T)).toFixed(6)),((100/td.length) * mape)];
	}
	
	//for(var k=0;k<td[0].output.length;k++)
	//{
	//	computeError(k);
	//}
	//console.log(JSON.stringify(net.toJSON()));
	//corrnet = net;
	return computeError(0);
}

function sqrt_exp(x)
{
	if(x < 0.5)
	{
		return Math.sqrt(x);
	}
	else
	{
		return Math.exp(x);
	}
}

function exp_log2(x)
{
	if(x < 0.5)
	{
		return Math.exp(x);
	}
	else
	{
		return Math.log2(x);
	}
}

function log2_exp(x)
{
	if(x < 0.5)
	{
		return Math.log2(x);
	}
	else
	{
		return Math.exp(x);
	}
}

function sqrt_sqrt(x)
{
	if(x < 0.5)
	{
		return Math.sqrt(x);
	}
	else
	{
		return 1.1 * Math.sqrt(x);
	}
}

function trainMath(ts_size,neurons)
{
	trainingdata = generateData(ts_size);
	
	trainingdata = remDup(trainingdata);
	
	console.log(trainingdata.length);
	
	const config = {
	  learningRate: 0.2,
	  hiddenLayers: neurons,
	  decayRate: 0.999,
	  activation: 'relu' // supported activation types: ['sigmoid', 'relu', 'leaky-relu', 'tanh']
	};
	
	
	var results = {};
	var th = 0.0000001;
	
	/*
	
	console.log("sqrt(pow)");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0],trainingdata[i].input[1]];
		var o = Math.sqrt(Math.pow(trainingdata[i].input[0], trainingdata[i].input[1]));
		trainingdata[i].output = [o];
	}
	results["sqrt(pow)"] = trainBN(config,trainingdata,th);

	console.log("log(pow)");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0],trainingdata[i].input[1]];
		var o = Math.log(Math.pow(trainingdata[i].input[0], trainingdata[i].input[1])+1);
		trainingdata[i].output = [o];
	}
	results["log(pow)"] = trainBN(config,trainingdata,th);
	
	
	console.log("log2_exp");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = log2_exp(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["log2_exp"] = trainBN(config,trainingdata,th);
	
	console.log("log(sqrt)");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0],trainingdata[i].input[1]];
		var o = Math.log(Math.sqrt(trainingdata[i].input[0])+1);
		trainingdata[i].output = [o];
	}
	results["log(sqrt)"] = trainBN(config,trainingdata,th);
	
	// x <- sort(runif(100))
	// y <- exp(sqrt(x))
	// y <- exp(x)
	console.log("exp(sqrt)");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0],trainingdata[i].input[1]];
		var o = Math.exp(Math.sqrt(trainingdata[i].input[0]+1));
		trainingdata[i].output = [o];
	}
	results["exp(sqrt)"] = trainBN(config,trainingdata,th);
	
	console.log("log2");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.log2(trainingdata[i].input[0]+1);
		trainingdata[i].output = [o];
	}
	results["log2"] = trainBN(config,trainingdata,th);
	
	console.log("exp");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.exp(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["exp"] = trainBN(config,trainingdata,th);
	
	
	console.log("exp_log2");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = exp_log2(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["exp_log2"] = trainBN(config,trainingdata,th);
	
	
	console.log("sqrt(exp)");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0],trainingdata[i].input[1]];
		var o = Math.sqrt(Math.exp(trainingdata[i].input[0]));
		trainingdata[i].output = [o];
	}
	results["sqrt(exp)"] = trainBN(config,trainingdata,th);
	
	console.log("sqrt_sqrt");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = sqrt_sqrt(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["sqrt_sqrt"] = trainBN(config,trainingdata,th);
	
	console.log("sqrt_exp");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = sqrt_exp(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["sqrt_exp"] = trainBN(config,trainingdata,th);
	
	*/
	
	
	console.log("pow");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0],trainingdata[i].input[1]];
		var o = Math.pow(trainingdata[i].input[0], trainingdata[i].input[1]);
		trainingdata[i].output = [o];
	}
	results["pow"] = trainBN(config,trainingdata,th);
	
	
	console.log("sqrt");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.sqrt(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["sqrt"] = trainBN(config,trainingdata,th);
	
	console.log("log");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.log(trainingdata[i].input[0]+1);
		trainingdata[i].output = [o];
	}
	results["log"] = trainBN(config,trainingdata,th);
	
	console.log("exp");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.exp(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["exp"] = trainBN(config,trainingdata,th);
	
	console.log("log10");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.log10(trainingdata[i].input[0]+1);
		trainingdata[i].output = [o];
	}
	results["log10"] = trainBN(config,trainingdata,th);
	
	console.log("log2");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.log2(trainingdata[i].input[0]+1);
		trainingdata[i].output = [o];
	}
	results["log2"] = trainBN(config,trainingdata,th);
	
	console.log("sinh");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.sinh(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["sinh"] = trainBN(config,trainingdata,th);
	
	console.log("cosh");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.cosh(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["cosh"] = trainBN(config,trainingdata,th);
	
	console.log("tanh");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.tanh(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["tanh"] = trainBN(config,trainingdata,th);
	
	console.log("asin");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.asin(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["asin"] = trainBN(config,trainingdata,th);
	
	console.log("acos");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.acos(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["acos"] = trainBN(config,trainingdata,th);
	
	console.log("atan");
	for(var i=0; i<trainingdata.length; i++)
	{
		trainingdata[i].input = [trainingdata[i].input[0]];
		var o = Math.atan(trainingdata[i].input[0]);
		trainingdata[i].output = [o];
	}
	results["atan"] = trainBN(config,trainingdata,th);
	
	
	
	
	//, "sqrt(pow)","log(pow)","log(sqrt)","exp(sqrt)","sqrt(exp)"];
	var s_mape = "";
	var s_smape = "";
	for(var i=0;i<functions.length;i++)
	{
		try
		{
			s_mape += results[functions[i]][0] + ";";
			s_smape += results[functions[i]][1] + ";";
		}
		catch(e){}
	}	
	
	mape.push(s_mape);
	smape.push(s_smape);
	
}

var functions = ["log", "log10", "log2", "pow", "sinh", "sqrt", "tanh", "cosh", "exp", "asin", "acos", "atan"]; 

var mape = [];
var smape = [];

function emptyResults()
{
	mape = [];
	smape = [];
}

function metaTrainMath(ts_size,runs,neurons)
{
	for(var i=0;i<runs;i++)
	{
		trainMath(ts_size,neurons);
	}	
	
	console.log("MAPE");
	
	var funs = "";
	for(var i=0;i<functions.length;i++)
	{
		funs += functions[i] + ";";
	}
	console.log(funs);
	for(var i=0;i<mape.length;i++)
	{
		console.log(mape[i]);
	}
	
	console.log("SMAPE");
	
	console.log(funs);
	
	for(var i=0;i<smape.length;i++)
	{
		console.log(smape[i]);
	}
}


function train()
{
	if(ndata.length == old_ndata_length) return;
	
	if(udata.length == 0)
	{
		tdata = JSON.stringify(tdata);
		tdata = tdata.replaceAll('[\"','[');
		tdata = tdata.replaceAll('\",\"',',');
		tdata = tdata.replaceAll('\"]',']');
		tdata = JSON.parse(tdata);
		udata = tdata.slice(0,10000);
		udata = filter(udata);
	}
	
	if(ndata.length > 0)
	{
		ndata = removeDuplicates(ndata);
		for(var i=0;i<ndata.length;i++)
		{
			if(ndata[i].input[0] < th_x_up) th_x_up = ndata[i].input[0];
			if(ndata[i].input[2] > th_x_down) th_x_down = ndata[i].input[2];
			if(ndata[i].input[1] > th_y) th_y = ndata[i].input[1];
			if(ndata[i].input[3] > th_y) th_y = ndata[i].input[3];
		}		
		udata = tdata.slice(0,10000);
		udata = filter(udata);
	}
	
	old_ndata_length = ndata.length;
	console.log("udata: " + udata.length);
	
	udata = udata.concat(ndata);
	udata = removeDuplicates(udata);
	
	console.log("udata + ndata: " + udata.length);
	
	shuffle(udata);
	shuffle(udata);
	shuffle(udata);
	
	const config = {
	  learningRate: 0.1,
	  hiddenLayers: [32,32,32,32,16],
	  activation: 'relu' // supported activation types: ['sigmoid', 'relu', 'leaky-relu', 'tanh']
	};

	const crossValidate = new brain.CrossValidate(brain.NeuralNetwork, config, k=3);
	const stats = crossValidate.train(udata, { log: true, iterations:5000, errorThresh: 0.0006, logPeriod: 100 }, k=3);
	console.log(stats);
	const net = crossValidate.toNeuralNetwork();

	//net.train(tdata,  { log: true, iterations:10000, errorThresh: 0.0001, logPeriod: 100 });

	function dn(x)
	{
		y = x * (MM - mm) + mm;
		return Math.round(y);
	}

	err_0 = 0;
	err_1 = 0;
	tests = 0;

	var d = new Date();
	console.log(d.getTime());
	
	for(var i=0; i< udata.length; i++)
	{

		o = net.run(udata[i].input);
		err_0 += Math.abs(udata[i].output[0] - o[0]) / udata.length;
		err_1 += Math.abs(udata[i].output[1] - o[1]) / udata.length;
		
		var test = testEllipse(100,dn(udata[i].input[0]),dn(udata[i].input[1]),dn(udata[i].input[2]),dn(udata[i].input[3]),dn(o[0]),dn(o[1]));
		if(test <= 1) tests++;
		
	}
	d = new Date();
	console.log(d.getTime());

	console.log(err_0); console.log(err_1); console.log(tests);
	
	var json = net.toJSON();
	models.push(jnn);
	jnn = JSON.stringify(json);
	
}


var models = [];