var interimResult = "";
var finalResult = "";

var finalTranscript = "";
var isRecognizing = false;

var SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;
var recognition = new SpeechRecognition();
recognition = new SpeechRecognition();
recognition.continuous = true;
recognition.interimResults = true;
recognition.lang = 'en_US';

function hideMessage()
{
	$("#elementHelp").hide();	
}

var showMessage = function(message, keep = 5000)
{
	$("#elementName").text("Speech Recognition");
	$("#elementHelp").html("<hr size='1'>" + message);
	$("#elementHelp").show();
	//setTimeout(function(){$("#elementHelp").hide();},keep);
};

var GLOBAL_VELOCITY = 30;
var GLOBAL_ACCELERATION = 30;
var GLOBAL_FORCE = 50;
var GLOBAL_LOAD = 100;
var CURRENT_APP = null;

var addAppToTask = function(taskId, appId, appIndex) {
	return new Promise(resolve=>{
		var resolvePromise = function()
		{
			resolve(20);
		};
		$.post("/desk/api/timelines/" + taskId + "/0/" + appIndex, {
			id: appId
		}).done(function(data) {
			console.log("Created app: " + appId);
			setTimeout(resolvePromise,500);
		});
	});
};

async function createAppInCurrentTask(appId)
{
	var appIndex = $("one-timeline-skill").length;
	console.log("appindex: " + appIndex);
	var taskId = $("span[data-bind='html: name']").text().toLowerCase();
	await addAppToTask(taskId, appId, appIndex);
			
	var triggerClick = function() { 
		console.log($("div.drag-area")[appIndex]); 
		$($("div.drag-area")[appIndex]).trigger("click"); 
		CURRENT_APP = appId; 
	};
	setTimeout(triggerClick,200);
}

var commands = [
{
  	command: "move to",
	description: "Adds the current robot pose as a waypoint to the program.",
    action: async function(cmd) {
		var elem = $("#wp").clone();
		elem.removeAttr("id");
		elem.removeClass("draggable");
		elem.insertBefore("li[name='stop']");
		addClickEvents(elem);
		indent();
    }
},
{
	command: "waypoint",
	description: "Adds the current robot pose as a waypoint to the program.",
	action: async function(cmd) {
		var elem = $("#wp").clone();
		elem.removeAttr("id");
		elem.removeClass("draggable");
		elem.insertBefore("li[name='stop']");
		addClickEvents(elem);
		indent();

		showMessage("<font color='darkred' size='6'><b>WAYPOINT</b></font>");
		setTimeout(hideMessage, 6000);
	}
},

{
	command: "okay",
  	action: async function(cmd) {
		showMessage("<font color='darkgrey' size='6'><b>OKAY</b></font>");
		setTimeout(hideMessage, 6000);
  	}
},

{
	command: "run program",
  	action: async function(cmd) {
		play();
  	}
},
{
	command: "parameters",
  	action: async function(cmd) {
		$("#ParamsContext").click();

		dcommands = [];
		for (var key in window.Params) {
			if (window.Params.hasOwnProperty(key)) {
				var act = async function(cmd){
					try
					{
						var digits = ["one","two","three","four","five","six","seven","eight","nine"];
						for(var i=0;i<digits.length;i++)
						{
							if(cmd[2] == digits[i])
							{
								cmd[2] = i+1;
								break;
							}
						}
						window.Params[cmd[1]] = parseFloat(cmd[2]);
					}
					catch(e)
					{
						window.Params[cmd[1]] = cmd[2];
					}
					$("#ParamsContext").click();
				};
				dcommands.push({command: "set " + key + " <string>", action: act});
			}
		}
  	}
},
{
	command: "variables",
  	action: async function(cmd) {
		$("#VarsContext").click();
		dcommands = [];
		for (var key in window.Vars) {
			if (window.Vars.hasOwnProperty(key)) {
				var act = async function(cmd){
					try
					{
						var digits = ["one","two","three","four","five","six","seven","eight","nine"];
						for(var i=0;i<digits.length;i++)
						{
							if(cmd[2] == digits[i])
							{
								cmd[2] = i+1;
								break;
							}
						}
						window.Vars[cmd[1]] = parseFloat(cmd[2]);
					}
					catch(e)
					{
						window.Vars[cmd[1]] = cmd[2];
					}
					$("#VarsContext").click();
				};
				dcommands.push({command: "set " + key + " <string>", action: act});
			}
		}

		act = async function(cmd){
			try
			{
				window.Vars[cmd[1]] = null;
				
				var act2 = async function(cmd){
					try
					{
						window.Vars[cmd[1]] = parseFloat(cmd[2]);
					}
					catch(e)
					{
						window.Vars[cmd[1]] = cmd[2];
					}
					$("#VarsContext").click();
				};
				dcommands.push({command: "set " + cmd[1] + " <string>", action: act2});
			}
			catch(e)
			{
				showMessage("<font color='darkred'>Variable name '" + cmd[1] + " is not permitted.</font>");
			}
			$("#VarsContext").click();
		};
		dcommands.push({command: "create <string>", action: act});
  	}
},
{
	command: "robot",
  	action: async function(cmd) {
		$("#RobotContext").click();
  	}
},
{
	command: "set variables",
  	action: async function(cmd) {
		var elem = $("li[name='setVars'].draggable").clone();
		elem.removeClass("draggable");
		elem.attr("params",btoa(JSON.stringify(Vars)));
		elem.insertBefore("li[name='stop']");
		addClickEvents(elem);
		indent();
  	}
},
{
	command: "set parameters",
  	action: async function(cmd) {
		var elem = $("li[name='setParams'].draggable").clone();
		elem.removeClass("draggable");
		elem.attr("params",btoa(JSON.stringify(Params)));
		elem.insertBefore("li[name='stop']");		
		addClickEvents(elem);
		indent();
  	}
},
{
	command: "if",
  	action: async function(cmd) {
		var elem = $("li[name='if'].draggable").clone();
		elem.removeClass("draggable");
		var cid = "ctrl_" + getRandomInt(10000);
		control_ids.push(cid);
		elem.attr("id",cid);
		elem.insertBefore("li[name='stop']");		
		addClickEvents(elem);
		indent();
  	}
},
{
	command: "else",
  	action: async function(cmd) {
		var elem = $("li[name='else'].draggable").clone();
		elem.removeClass("draggable");
		elem.insertBefore("li[name='stop']");	
		addClickEvents(elem);	
		indent();
  	}
},
{
	command: "else if",
  	action: async function(cmd) {
		var elem = $("li[name='elseif'].draggable").clone();
		elem.removeClass("draggable");
		elem.insertBefore("li[name='stop']");	
		addClickEvents(elem);	
		indent();
  	}
},

{
	command: "and if",
  	action: async function(cmd) {
		var cid = control_ids.pop();
		var elem = $('<li name="wrapper" head="'+cid+'" class="if leftRounded">&nbsp;&nbsp;</li>');
		elem.insertBefore("li[name='stop']");		
		addClickEvents(elem);
		indent();
  	}
},
{
	command: "while",
  	action: async function(cmd) {
		var elem = $("li[name='while'].draggable").clone();
		elem.removeClass("draggable");
		var cid = "ctrl_" + getRandomInt(10000);
		control_ids.push(cid);
		elem.attr("id",cid);
		elem.insertBefore("li[name='stop']");	
		addClickEvents(elem);	
		indent();
  	}
},
{
	command: "break",
  	action: async function(cmd) {
		var elem = $("li[name='break'].draggable").clone();
		elem.removeClass("draggable");
		elem.insertBefore("li[name='stop']");	
		addClickEvents(elem);	
		indent();
  	}
},
{
	command: "and while",
  	action: async function(cmd) {
		var cid = control_ids.pop();
		var elem = $('<li name="wrapper" head="'+cid+'" class="while leftRounded">&nbsp;&nbsp;</li>');
		elem.insertBefore("li[name='stop']");	
		addClickEvents(elem);	
		indent();
  	}
},
{
	command: "repeat",
  	action: async function(cmd) {
		var elem = $("li[name='repeat'].draggable").clone();
		elem.removeClass("draggable");
		var cid = "ctrl_" + getRandomInt(10000);
		control_ids.push(cid);
		elem.attr("id",cid);
		elem.insertBefore("li[name='stop']");	
		addClickEvents(elem);	
		indent();
  	}
},

{
	command: "and repeat",
  	action: async function(cmd) {
		var cid = control_ids.pop();
		var elem = $('<li name="wrapper" head="'+cid+'" class="repeat leftRounded">&nbsp;&nbsp;</li>');
		elem.insertBefore("li[name='stop']");		
		indent();
  	}
},

{
	command: "open",
  	action: async function(cmd) {
		var elem = $("li[name='gripperOpen'].draggable").clone();
		elem.removeClass("draggable");
		elem.insertBefore("li[name='stop']");	
		addClickEvents(elem);	
		indent();
  	}
},
{
	command: "close",
  	action: async function(cmd) {
		var elem = $("li[name='gripperClose'].draggable").clone();
		elem.removeClass("draggable");
		elem.insertBefore("li[name='stop']");		
		addClickEvents(elem);
		indent();
  	}
},
{
	command: "delete",
  	action: async function(cmd) {
		$("li[name='stop']").prev().remove();		
		indent();
  	}
},


];

var dcommands = [];

var control_ids = [];

function getRandomInt(max) {
	return Math.floor(Math.random() * max);
}

function escapeHtml(unsafe) {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
};

var VOICE_COMMANDS_ENABLED = false;
function startSpeechRecognition()
{ 
	if(VOICE_COMMANDS_ENABLED) return;
	recognition.start();
	VOICE_COMMANDS_ENABLED = true;
	var commandList = "";
	for(var i=0;i<commands.length;i++)
	{
		commandList += escapeHtml(commands[i].command.replaceAll("and ","end ")) + "; ";
	}
	showMessage("<font color='darkgreen'>Speech recognition is active.</font> The following commands are available: <i> " + commandList + "</i>",5000);
}

function stopSpeechRecognition()
{ 
	if(!VOICE_COMMANDS_ENABLED) return;
	recognition.stop();
	VOICE_COMMANDS_ENABLED = false;
}

var matchCommand = function(transcript) {
  var rec = transcript.replaceAll("- ","-").replaceAll("+ ","+").trim().toLowerCase().split(/[\s\/]+/);
  var cmds = commands.concat(dcommands);
  for (var i = 0; i < cmds.length; i++) {
    var cmd = cmds[i].command.split(/[\s\/]+/);
    if (cmd.length == rec.length) {
      var matched = true;
      for (var j = 0; j < rec.length; j++) {
        if ((rec[j] != cmd[j] && cmd[j] != "<integer>" && cmd[j] != "<string>") ||
          (cmd[j] == "<integer>" && isNaN(parseInt(rec[j])))) {
          matched = false;
          break;
        }
      }
      if (matched) {
        return {
          match: rec,
          command: cmds[i].command,
          action: cmds[i].action
        };
      }
    }
  }
  return null;
};

recognition.onresult = function(event) {
  console.log("onresult");
  for (var i = event.resultIndex; i < event.results.length; i++) {
    var _transcript = event.results[i][0].transcript;
    if (event.results[i].isFinal) {
      finalTranscript += _transcript + " ";
	  console.log(finalTranscript);
      var cmd = matchCommand(finalTranscript);
      if (cmd != null) {
        console.log("matched: " + cmd.match.join(" ").replaceAll("and ","end "));
		
		showMessage("<font color='darkgreen'>Matched command: </font><i>" + cmd.match.join(" ").replaceAll("and ","end ") + "</i>", 3000);
		
		cmd.action(cmd.match);
      }
	  else
	  {
		  showMessage("<font color='darkred'>Wrong command: </font><i>" + finalTranscript + "</i>", 2000);		  
	  }
    }
  }
  finalTranscript = "";
};

var restartRecognition = function()
{
	if(!VOICE_COMMANDS_ENABLED) return;
	var startRecognition = function()
	{
		recognition.start();
		restarting = false;
	};
	recognition.stop();
	recognition.abort();
	setTimeout(startRecognition,300);
};

var restarting = false;
recognition.onerror = function(event) {
	console.log(event.error);
	if(!VOICE_COMMANDS_ENABLED) return;
	$("#voice_commands").click();
	showMessage("<font color='darkgreen'>Speech recognition is not inactive (automatic deactivation after 10 seconds).</font>");
	/*
	if(!restarting)
	{
		restarting = true;
		setTimeout(restartRecognition,100);
	}*/

};

recognition.onaudioend = function(event) {
	console.log("onaudioend");
};

recognition.onspeechend = function(event) {
	console.log("onspeechend");
	if(!VOICE_COMMANDS_ENABLED) return;
	$("#voice_commands").click();
	showMessage("<font color='darkgreen'>Speech recognition is not inactive (automatic deactivation after 10 seconds).</font>");
	/*
	if(!restarting)
	{
		restarting = true;
		setTimeout(restartRecognition,100);
	}
	*/
};
